﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

namespace Task_3
{
    class Program
    {
        public static Random Rand = new Random();

        static void Main(string[] args)
        {
            Image image = new Image(32, 32);

            image.RandomPaint();
            image.Draw();

            //Сериализация
            //при использовании BinaryFormatter - код сериализации максимально непонятный
            IFormatter formatter = new BinaryFormatter();
            using (Stream stream = File.OpenWrite("Images_binary.txt"))
                formatter.Serialize(stream, image);

            //при использовании SoapFormatter - код понятный
            IFormatter soap_formatter = new SoapFormatter();
            using (Stream stream = File.OpenWrite("Images_soap.txt"))
                soap_formatter.Serialize(stream, image);

            //однако файл Images_binary получился всего 13.5 Кб
            //файл Images_soap получился 65 Кб
        }
    }
}
