﻿namespace Task_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] files = Directory.GetFiles(@".\");  //файлы из текущей папки

			Console.WriteLine("yo");
			
            foreach (string fileName in files)
                Console.WriteLine(fileName);


			//Цикл
            foreach(string file in files)
            {
                File.Copy(file, Path.Combine(Directory.GetCurrentDirectory(), file + ".bak"));
            }

            foreach(string file in files)
                Console.WriteLine(file);
        }
    }
}
