﻿namespace BlazorApp.Data;

public class CurrentUser
{
    public string UserName { get; set; }

    //public string GetUserName => userName;
    //public string SetUserName(string name) => userName = name;

    // public CurrentUser(string userName)
    // {
    //     UserName = userName;
    // }
}