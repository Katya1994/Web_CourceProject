﻿namespace BlazorApp.Data;

public class SimpleChecking: IChecking
{
    public Dictionary<string, List<string>> CheckingDictionary { get; private set; } = new Dictionary<string, List<string>>();

    public double CalculateUniquenessPercent(string currentUser, Dictionary<string, List<string>> dictionary)
    {
        CheckingDictionary = dictionary;
        
        return LineAnalize(dictionary[currentUser], 
            dictionary.Where(i => i.Key != currentUser).Select(k => k.Value).ToList());
    }
    
    public List<string> CleanText(string[] lines)
    {
        List<string> list = new List<string>();

        foreach (string line in lines)
        {
            if (!string.IsNullOrWhiteSpace(line))
            {
                foreach (var ch in line)
                {
                    if (char.IsLetterOrDigit(ch))
                    {
                        list.Add(line.Trim().ToLower());
                        break;
                    }
                }
            }
        }
        return list;
    }
    
    public double LineAnalize(List<string> myList, List<List<string>> checkLIst)
    {
        double result = 0;

        foreach(var list in checkLIst)
        {
            for(int i = 0; i < list.Count; i++)
            {
                for(int j = 0; j < myList.Count; j++)
                {
                    if (myList[j] == list[i])
                    {
                        result++;
                        break;
                    }                            
                }
            }
        }

        return result/myList.Count * 100;
    }
}